 import { SlashCommandBuilder } from 'discord.js';
import { createEmbed } from '../../utils/embeds.js';

const afkUsers = new Map();

export function getAfkKey(guildId, userId) {
    return `${guildId}:${userId}`;
}

export function formatAFKDuration(ms) {
    const totalSeconds = Math.max(0, Math.floor(ms / 1000));

    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    const parts = [];

    if (days > 0) {
        parts.push(`${days} day${days === 1 ? '' : 's'}`);
    }

    if (hours > 0) {
        parts.push(`${hours} hour${hours === 1 ? '' : 's'}`);
    }

    if (minutes > 0) {
        parts.push(`${minutes} minute${minutes === 1 ? '' : 's'}`);
    }

    if (seconds > 0 || parts.length === 0) {
        parts.push(`${seconds} second${seconds === 1 ? '' : 's'}`);
    }

    if (parts.length > 2) {
        return `${parts[0]}, ${parts[1]} and ${parts[2]}`;
    }

    if (parts.length === 2) {
        return `${parts[0]} and ${parts[1]}`;
    }

    return parts[0];
}

function getDisplayName(user, member = null) {
    return (
        member?.displayName ||
        user.globalName ||
        user.displayName ||
        user.username
    );
}

export function createAFKSetEmbed(user, member, reason) {
    const displayName = getDisplayName(user, member);

    return createEmbed({
        title: `${displayName}, Your AFK has been set!`,
        description:
            `You are now AFK.\n\n` +
            `**Reason:** ${reason}`,
        color: 'primary',
        thumbnail: user.displayAvatarURL({ size: 256 }),
    });
}

export function createAFKMentionEmbed(user, member, data) {
    const displayName = getDisplayName(user, member);
    const duration = formatAFKDuration(Date.now() - data.since);

    return createEmbed({
        title: `${displayName} is AFK`,
        description:
            `They went AFK **${duration}** ago.\n\n` +
            `**Reason:** ${data.reason}`,
        color: 'primary',
        thumbnail: user.displayAvatarURL({ size: 256 }),
    });
}

export function createAFKWelcomeBackEmbed(user, member, data) {
    const displayName = getDisplayName(user, member);
    const duration = formatAFKDuration(Date.now() - data.since);

    const fields = [];

    if (data.mentions?.length) {
        const mentionLines = data.mentions
            .slice(0, 10)
            .map((mention, index) => {
                const messageUrl =
                    `https://discord.com/channels/` +
                    `${data.guildId}/${mention.channelId}/${mention.messageId}`;

                return (
                    `${index + 1}. <@${mention.userId}> — ` +
                    `[Jump to message](${messageUrl})`
                );
            });

        if (data.mentions.length > 10) {
            mentionLines.push(
                `...and ${data.mentions.length - 10} more mention` +
                `${data.mentions.length - 10 === 1 ? '' : 's'}.`
            );
        }

        fields.push({
            name: 'Mentions',
            value: mentionLines.join('\n'),
            inline: false,
        });
    } else {
        fields.push({
            name: 'Mentions',
            value: 'No one mentioned you while you were AFK.',
            inline: false,
        });
    }

    return createEmbed({
        title: `${displayName}, Welcome Back!`,
        description:
            `You went AFK **${duration}** ago.\n\n` +
            `**Reason:** ${data.reason}`,
        color: 'primary',
        fields,
        thumbnail: user.displayAvatarURL({ size: 256 }),
    });
}

export default {
    data: new SlashCommandBuilder()
        .setName('afk')
        .setDescription('Set your AFK status.')
        .addStringOption(option =>
            option
                .setName('reason')
                .setDescription('Why are you AFK?')
                .setRequired(false)
        ),

    category: 'Utility',

    async execute(interaction) {
        if (!interaction.guildId) {
            return interaction.reply({
                content: 'This command can only be used inside a server.',
                ephemeral: true,
            });
        }

        const reason =
            interaction.options.getString('reason')?.trim() || 'AFK';

        const key = getAfkKey(
            interaction.guildId,
            interaction.user.id
        );

        const member =
            interaction.member &&
            typeof interaction.member === 'object'
                ? interaction.member
                : null;

        afkUsers.set(key, {
            guildId: interaction.guildId,
            userId: interaction.user.id,
            reason,
            since: Date.now(),
            mentions: [],
        });

        await interaction.reply({
            embeds: [
                createAFKSetEmbed(
                    interaction.user,
                    member,
                    reason
                ),
            ],
        });
    },

    afkUsers,
};
