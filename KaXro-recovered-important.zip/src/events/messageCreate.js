 import { Events } from 'discord.js';

import { logger } from '../utils/logger.js';

import {
    getLevelingConfig,
    getUserLevelData,
} from '../services/leveling/leveling.js';

import { addXp } from '../services/leveling/xpSystem.js';

import { checkRateLimit } from '../utils/rateLimiter.js';

import { parsePrefixCommand } from '../utils/prefixParser.js';

import {
    supportsPrefixExecution,
    executePrefixCommand,
    resolvePrefixAccessKey,
} from '../utils/messageAdapter.js';

import {
    resolveCommandAlias,
    resolveSubcommandAlias,
} from '../config/commands/commandAliases.js';

import { getPrefixRestriction } from '../config/commands/prefixRestrictions.js';

import { getGuildConfig } from '../services/config/guildConfig.js';

import {
    getCommandPrefix,
    getBotMessage,
    isBotOwner,
    isCommandCategoryEnabled,
    isMaintenanceMode,
} from '../config/bot.js';

import {
    enforceAbuseProtection,
    formatCooldownDuration,
} from '../utils/abuseProtection.js';

import { createEmbed } from '../utils/embeds.js';

import { isCommandEnabled } from '../services/commandAccessService.js';

import {
    getCountingGameConfig,
    saveCountingGameConfig,
    isValidCountingMessage,
    recordCorrectCount,
} from '../services/countingGameService.js';

import afkCommand, {
    getAfkKey,
    formatAFKDuration,
    createAFKSetEmbed,
    createAFKMentionEmbed,
    createAFKWelcomeBackEmbed,
} from '../commands/Utility/afk.js';

const MESSAGE_XP_RATE_LIMIT_ATTEMPTS = 12;
const MESSAGE_XP_RATE_LIMIT_WINDOW_MS = 10000;

export default {
    name: Events.MessageCreate,

    async execute(message, client) {
        try {
            if (message.author.bot || !message.guild) {
                return;
            }

            logger.debug(
                `Message received from ${message.author.tag}: ${message.content}`
            );

            /*
             * AFK COMMAND
             *
             * Handles:
             * !afk
             * !afk reason
             * .afk
             * .afk reason
             *
             * This is handled before normal AFK removal so
             * an already-AFK user can update their AFK reason.
             */
            const afkCommandHandled = await handleAFKCommand(
                message,
                client
            );

            if (afkCommandHandled) {
                return;
            }

            /*
             * AFK ACTIVITY
             *
             * Removes the author's AFK status when they talk
             * and notifies them if someone mentioned them while AFK.
             */
            await handleAFKActivity(message);

            /*
             * COUNTING GAME
             */
            const countingProcessed = await handleCountingGame(
                message,
                client
            );

            if (countingProcessed) {
                return;
            }

            /*
             * NORMAL PREFIX COMMANDS
             */
            await handlePrefixCommand(message, client);

            /*
             * LEVELING
             */
            await handleLeveling(message, client);
        } catch (error) {
            logger.error(
                'Error in messageCreate event:',
                error
            );
        }
    },
};


/* ============================================================
   AFK COMMAND
   ============================================================ */

async function handleAFKCommand(message, client) {
    try {
        const content = message.content?.trim();

        if (!content) {
            return false;
        }

        const guildConfig = await getGuildConfig(
            client,
            message.guild.id
        );

        const configuredPrefix =
            guildConfig?.prefix || getCommandPrefix();

        const commandPrefixes = [
            configuredPrefix,
            '!',
            '.',
        ].filter(
            (prefix, index, array) =>
                prefix &&
                array.indexOf(prefix) === index
        );

        let reason = null;
        let matched = false;

        for (const prefix of commandPrefixes) {
            const commandStart =
                `${prefix}afk`;

            if (
                content.toLowerCase() ===
                commandStart.toLowerCase()
            ) {
                reason = 'AFK';
                matched = true;
                break;
            }

            if (
                content
                    .toLowerCase()
                    .startsWith(
                        `${commandStart.toLowerCase()} `
                    )
            ) {
                reason =
                    content
                        .slice(commandStart.length)
                        .trim() || 'AFK';

                matched = true;
                break;
            }
        }

        if (!matched) {
            return false;
        }

        /*
         * Respect the normal command settings.
         */
        if (
            isMaintenanceMode() &&
            !isBotOwner(message.author.id)
        ) {
            await message.channel.send({
                embeds: [
                    createEmbed({
                        title: 'Maintenance Mode',
                        description:
                            getBotMessage(
                                'maintenanceMode'
                            ),
                        color: 'warning',
                    }),
                ],
            }).catch(() => {});

            return true;
        }

        if (!isCommandCategoryEnabled('Utility')) {
            await message.channel.send({
                embeds: [
                    createEmbed({
                        title: 'Feature Disabled',
                        description:
                            getBotMessage(
                                'commandDisabled'
                            ),
                        color: 'error',
                    }),
                ],
            }).catch(() => {});

            return true;
        }

        const command = client.commands.get('afk');

        /*
         * If the command loader has not loaded AFK,
         * use the imported command directly.
         */
        const afk = command || afkCommand;

        if (!afk) {
            logger.error(
                'AFK command could not be loaded.'
            );

            return true;
        }

        /*
         * Check command access if available.
         */
        try {
            const enabled = await isCommandEnabled(
                client,
                message.guild.id,
                resolvePrefixAccessKey(
                    afk.data,
                    []
                ),
                afk.category
            );

            if (!enabled) {
                await message.channel.send({
                    embeds: [
                        createEmbed({
                            title: 'Command Disabled',
                            description:
                                'This command has been disabled for this server.',
                            color: 'error',
                        }),
                    ],
                }).catch(() => {});

                return true;
            }
        } catch (error) {
            logger.warn(
                'Could not check AFK command access:',
                error
            );
        }

        const key = getAfkKey(
            message.guild.id,
            message.author.id
        );

        const member =
            message.member || null;

        afk.afkUsers.set(key, {
            guildId: message.guild.id,
            userId: message.author.id,
            reason,
            since: Date.now(),
            mentions: [],
        });

        const embed = createAFKSetEmbed(
            message.author,
            member,
            reason
        );

        await message.channel.send({
            embeds: [embed],
        });

        logger.info(
            `${message.author.tag} set AFK in ${message.guild.name}: ${reason}`
        );

        return true;
    } catch (error) {
        logger.error(
            'Error handling AFK command:',
            error
        );

        return false;
    }
}


/* ============================================================
   AFK ACTIVITY
   ============================================================ */

async function handleAFKActivity(message) {
    try {
        const afkUsers = afkCommand.afkUsers;

        const authorKey = getAfkKey(
            message.guild.id,
            message.author.id
        );

        /*
         * First remove the author's own AFK status.
         *
         * This happens before checking mentions so that
         * their first normal message counts as their return.
         */
        const authorAFK = afkUsers.get(authorKey);

        if (authorAFK) {
            afkUsers.delete(authorKey);

            const welcomeEmbed =
                createAFKWelcomeBackEmbed(
                    message.author,
                    message.member,
                    authorAFK
                );

            await message.channel.send({
                embeds: [welcomeEmbed],
                allowedMentions: {
                    parse: [],
                },
            }).catch(() => {});
        }

        /*
         * Find everyone mentioned in this message.
         */
        const mentionedUsers = message.mentions.users;

        if (!mentionedUsers || mentionedUsers.size === 0) {
            return;
        }

        /*
         * Prevent multiple notifications for the same
         * AFK user in one message.
         */
        const alreadyProcessed = new Set();

        for (const user of mentionedUsers.values()) {
            if (!user || user.bot) {
                continue;
            }

            if (user.id === message.author.id) {
                continue;
            }

            if (alreadyProcessed.has(user.id)) {
                continue;
            }

            alreadyProcessed.add(user.id);

            const key = getAfkKey(
                message.guild.id,
                user.id
            );

            const afkData = afkUsers.get(key);

            if (!afkData) {
                continue;
            }

            /*
             * Store the mention so it appears in
             * the user's Welcome Back message.
             */
            if (!Array.isArray(afkData.mentions)) {
                afkData.mentions = [];
            }

            const mentionAlreadyStored =
                afkData.mentions.some(
                    mention =>
                        mention.messageId ===
                        message.id
                );

            if (!mentionAlreadyStored) {
                afkData.mentions.push({
                    userId: message.author.id,
                    messageId: message.id,
                    channelId: message.channel.id,
                    timestamp: Date.now(),
                });
            }

            /*
             * Keep memory small.
             */
            if (afkData.mentions.length > 10) {
                afkData.mentions =
                    afkData.mentions.slice(-10);
            }

            afkUsers.set(key, afkData);

            /*
             * Fetch the mentioned member if possible.
             */
            const member =
                message.guild.members.cache.get(
                    user.id
                ) ||
                await message.guild.members
                    .fetch(user.id)
                    .catch(() => null);

            const mentionEmbed =
                createAFKMentionEmbed(
                    user,
                    member,
                    afkData
                );

            await message.channel.send({
                embeds: [mentionEmbed],
                allowedMentions: {
                    parse: [],
                },
            }).catch(() => {});
        }
    } catch (error) {
        logger.error(
            'Error handling AFK activity:',
            error
        );
    }
}


/* ============================================================
   PREFIX COMMANDS
   ============================================================ */

async function handlePrefixCommand(message, client) {
    try {
        const guildConfig = await getGuildConfig(
            client,
            message.guild.id
        );

        const prefix =
            guildConfig?.prefix ||
            getCommandPrefix();

        const parsed = parsePrefixCommand(
            message.content,
            prefix
        );

        if (!parsed) {
            return;
        }

        let { commandName, args } = parsed;

        const musicPrefixShortcut =
            commandName.toLowerCase();

        const MUSIC_PREFIX_SHORTCUTS = new Set([
            'leave',
            'pause',
            'resume',
            'skip',
            'stop',
            'volume',
        ]);

        if (
            MUSIC_PREFIX_SHORTCUTS.has(
                musicPrefixShortcut
            )
        ) {
            commandName = 'music';
            args = [
                musicPrefixShortcut,
                ...args,
            ];
        }

        logger.info(
            `Prefix command detected: ${commandName}, args: ${args.join(', ')}`
        );

        const resolvedCommandName =
            resolveCommandAlias(commandName);

        logger.info(
            `Resolved command name: ${resolvedCommandName}`
        );

        const command =
            client.commands.get(
                resolvedCommandName
            );

        if (!command) {
            logger.warn(
                `Command not found: ${resolvedCommandName}`
            );

            return;
        }

        if (
            isMaintenanceMode() &&
            !isBotOwner(message.author.id)
        ) {
            await message.channel.send({
                embeds: [
                    createEmbed({
                        title: 'Maintenance Mode',
                        description:
                            getBotMessage(
                                'maintenanceMode'
                            ),
                        color: 'warning',
                    }),
                ],
            }).catch(() => {});

            return;
        }

        if (
            !isCommandCategoryEnabled(
                command.category
            )
        ) {
            await message.channel.send({
                embeds: [
                    createEmbed({
                        title: 'Feature Disabled',
                        description:
                            getBotMessage(
                                'commandDisabled'
                            ),
                        color: 'error',
                    }),
                ],
            }).catch(() => {});

            return;
        }

        const restriction =
            getPrefixRestriction(
                command,
                args,
                resolveSubcommandAlias
            );

        if (
            !supportsPrefixExecution(
                command
            ) ||
            restriction.blocked
        ) {
            if (
                restriction.blocked &&
                restriction.reason
            ) {
                const embed = createEmbed({
                    title: 'Slash Command Only',
                    description:
                        `${restriction.reason}\n` +
                        `Use \`/${resolvedCommandName}\` instead.`,
                    color: 'info',
                });

                await message.channel.send({
                    embeds: [embed],
                }).catch(() => {});
            }

            return;
        }

        if (
            !(await isCommandEnabled(
                client,
                message.guild.id,
                resolvePrefixAccessKey(
                    command.data,
                    args
                ),
                command.category
            ))
        ) {
            const embed = createEmbed({
                title: 'Command Disabled',
                description:
                    'This command has been disabled for this server.',
                color: 'error',
            });

            await message.channel.send({
                embeds: [embed],
            }).catch(() => {});

            return;
        }

        const mockInteractionForProtection = {
            guildId: message.guild.id,
            user: message.author,
        };

        const abuseProtection =
            await enforceAbuseProtection(
                mockInteractionForProtection,
                command,
                resolvedCommandName
            );

        if (!abuseProtection.allowed) {
            const formattedCooldown =
                formatCooldownDuration(
                    abuseProtection.remainingMs
                );

            const embed = createEmbed({
                title: 'Command Cooldown',
                description:
                    `This command is on cooldown. ` +
                    `Please wait ${formattedCooldown} ` +
                    `before trying again.`,
                color: 'error',
            });

            await message.channel.send({
                embeds: [embed],
            }).catch(() => {});

            return;
        }

        logger.info(
            `Executing prefix command: ${prefix}${commandName} ` +
            `(resolved to ${resolvedCommandName}) ` +
            `by ${message.author.tag}`
        );

        await executePrefixCommand(
            command,
            message,
            args,
            client,
            prefix,
            guildConfig
        );
    } catch (error) {
        logger.error(
            'Error handling prefix command:',
            error
        );
    }
}


/* ============================================================
   COUNTING GAME
   ============================================================ */

async function handleCountingGame(message, client) {
    try {
        const config =
            await getCountingGameConfig(
                client,
                message.guild.id
            );

        if (
            !config.enabled ||
            !config.channelId ||
            message.channel.id !==
                config.channelId
        ) {
            return false;
        }

        const content =
            message.content.trim();

        const validCount =
            isValidCountingMessage(
                content,
                config
            );

        const invalidAttempt =
            !validCount ||
            message.author.id ===
                config.lastUserId;

        if (invalidAttempt) {
            await message.delete()
                .catch(() => {});

            await saveCountingGameConfig(
                client,
                message.guild.id,
                {
                    ...config,
                    nextNumber: 1,
                    lastUserId: null,
                    currentStreak: 0,
                }
            );

            const failureMessage =
                await message.channel.send(
                    `Count broken by <@${message.author.id}>. ` +
                    `The sequence has been reset to **1**.`
                );

            setTimeout(() => {
                failureMessage
                    .delete()
                    .catch(() => {});
            }, 10000);

            return true;
        }

        await recordCorrectCount(
            client,
            message.guild.id,
            message.author.id
        );

        return true;
    } catch (error) {
        logger.error(
            'Error handling counting game:',
            error
        );

        retur
